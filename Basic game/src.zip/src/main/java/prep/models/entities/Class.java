package prep.models.entities;

public enum  Class {

    warrior, archer, mage;
}
